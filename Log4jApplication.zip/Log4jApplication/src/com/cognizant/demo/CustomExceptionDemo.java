package com.cognizant.demo;

import com.cognizant.service.HelloService;

public class CustomExceptionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HelloService service=new HelloService();
		service.businessMethod(20000);

	}

}
