package com.cognizant.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HelloController {
	protected final Log logger = LogFactory.getLog(getClass());

	@RequestMapping(value="hello.htm",method=RequestMethod.GET)
	public String sayHello(){
		int d=90;
		logger.info("*********sayHello method call"+d);
        try{
		int c=1/0;
        }catch(ArithmeticException e){
        	logger.error(e);
        }
        
		
		return "hello";
		
	}

}
