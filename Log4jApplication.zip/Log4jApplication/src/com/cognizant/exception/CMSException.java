package com.cognizant.exception;

public class CMSException extends RuntimeException{
	
	String message;
	
	public CMSException(String message){
		this.message=message;
	}
	
	public String getMessage(){
		return message;
	}
	

}
