package com.cognizant.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.cognizant.exception.CMSException;

public class HelloService {
	
	protected final Log logger = LogFactory.getLog(getClass());

	public void businessMethod(double amount){
		logger.info("Business Method called"+amount);
		if(amount>10000){
			try{
			throw new CMSException("Amount greater than transaction limit");
			}catch(CMSException cms){
				logger.error(cms);
			}
		}
	}

}
