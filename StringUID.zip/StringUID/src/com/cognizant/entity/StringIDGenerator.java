package com.cognizant.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.UUID;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.id.IdentifierGenerator;

public class StringIDGenerator implements IdentifierGenerator {

	@Override
	public Serializable generate(SessionImplementor arg0, Object arg1)
			throws HibernateException {
		// TODO Auto-generated method stub
		AnnotationConfiguration configuration=new AnnotationConfiguration();
		configuration.configure();
		SessionFactory factory=
				configuration.buildSessionFactory();
		Session session=factory.openSession();
		 Query query = session.createSQLQuery( "select panSEQ.nextval FROM DUAL" );
		    Long key = ((BigDecimal) query.uniqueResult()).longValue();
		    return "PAN"+key;
	}

}
