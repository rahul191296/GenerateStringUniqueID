package com.cognizant.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="PanCard")
public class PanCard {
	@Id
    @GenericGenerator(name = "panCard_SEQ", 
    strategy = "com.cognizant.entity.StringIDGenerator")
    @GeneratedValue(generator = "panCard_SEQ")
	@Column(name="Pan_CardNo")
	private String panCardNo;
	@Column(name="Holder_Name")
	private String holderName;
	public String getPanCardNo() {
		return panCardNo;
	}
	public void setPanCardNo(String panCardNo) {
		this.panCardNo = panCardNo;
	}
	public String getHolderName() {
		return holderName;
	}
	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}
	
	
	
	

}
