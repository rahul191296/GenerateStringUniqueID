package com.cognizant.demo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class CharacterSeq {
	static String str(double i) {
	    return i < 0  ? "" : str((i / 26) - 1) + (char)(65 + i % 26);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<String> idList=new ArrayList<String>();
		
		for(double i=999999999973d;i<1000000000000d;i++){
	        String id=str(i);
	        idList.add(id);
		}
		for(int i=0;i<=26;i++){
			System.out.println(idList.get(i));

		}
		
	    
	}

}
